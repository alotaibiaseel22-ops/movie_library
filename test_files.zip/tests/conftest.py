import json, os, pytest, tempfile, shutil

@pytest.fixture
def temp_data(monkeypatch):
    tmp = tempfile.mkdtemp()

    movies = [
        {"id": "m1", "title": "Inception", "genre": "Sci-Fi", "tags": ["dream"]},
        {"id": "m2", "title": "Interstellar", "genre": "Sci-Fi", "tags": ["space"]},
        {"id": "m3", "title": "The Dark Knight", "genre": "Action", "tags": ["hero", "crime"]}
    ]
    users = [
        {"id": "u1", "name": "Alice", "username": "alice", "password": "pass", "preferences": ["Sci-Fi"]}
    ]

    os.makedirs(f"{tmp}/data", exist_ok=True)
    open(f"{tmp}/data/movies.json", "w").write(json.dumps(movies))
    open(f"{tmp}/data/users.json", "w").write(json.dumps(users))

    monkeypatch.setenv("MOVIES_JSON_PATH", f"{tmp}/data/movies.json")
    monkeypatch.setenv("USERS_JSON_PATH", f"{tmp}/data/users.json")

    yield tmp
    shutil.rmtree(tmp)
