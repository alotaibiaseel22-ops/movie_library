def test_recommend(temp_data, monkeypatch):
    monkeypatch.setenv("AI_BACKEND", "mock")
    from app.recommendation_service import RecommendationService
    svc = RecommendationService()

    recs = svc.recommend_for_user("u1", k=2)
    assert len(recs) == 2
