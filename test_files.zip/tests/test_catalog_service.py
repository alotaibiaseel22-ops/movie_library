def test_catalog(temp_data):
    from app.catalog_service import CatalogService
    svc = CatalogService()

    initial = svc.list_movies()
    count = len(initial)

    new_movie = {"title": "Tenet", "genre": "Sci-Fi", "tags": ["time"]}
    created = svc.add_movie(new_movie)
    assert created["title"] == "Tenet"

    retrieved = svc.get_movie(created["id"])
    assert retrieved is not None

    svc.delete_movie(created["id"])
    assert svc.get_movie(created["id"]) is None
    assert len(svc.list_movies()) == count
