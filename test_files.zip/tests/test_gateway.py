def test_gateway_flow(temp_data, monkeypatch):
    monkeypatch.setenv("AI_BACKEND", "mock")
    from app.gateway import APIGateway

    gw = APIGateway()

    movies = gw.list_movies()
    assert len(movies) >= 3

    u = gw.register_user("u10", "Dana", "dana", "pass", ["Sci-Fi"])
    assert u["username"] == "dana"

    auth = gw.authenticate("dana", "pass")
    assert auth is not None

    recs = gw.recommend("u10", k=2)
    assert len(recs) == 2
