def test_account(temp_data):
    from app.account_service import AccountService
    svc = AccountService()

    user = svc.register_user("u9", "Bob", "bob", "pw", ["Action"])
    assert user["username"] == "bob"

    authed = svc.authenticate("bob", "pw")
    assert authed["id"] == "u9"

    wrong = svc.authenticate("bob", "wrong")
    assert wrong is None
