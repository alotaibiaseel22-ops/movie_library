from typing import List, Dict, Any
import os
import google.generativeai as genai


class GeminiAdapter:
    """Adapter that integrates Google Gemini for movie recommendations."""

    def __init__(self):
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            raise ValueError("Missing Gemini API key. Please set GEMINI_API_KEY.")
        genai.configure(api_key=api_key)
        self.model = genai.GenerativeModel("gemini-1.5-flash")

    def recommend(self, user_profile: Dict[str, Any], movies: List[Dict[str, Any]], k: int = 5) -> List[Dict[str, Any]]:
        prefs = ", ".join(user_profile.get("preferences", []))
        movie_titles = ", ".join([m["title"] for m in movies])

        prompt = (
            f"The user prefers: {prefs}. "
            f"Here are the available movies: {movie_titles}. "
            f"Recommend the top {k} most relevant movies."
        )

        response = self.model.generate_content(prompt)
        text = response.text.strip()
        ranked = [m for m in movies if any(t.lower() in text.lower() for t in [m["title"], m["genre"]])]
        return ranked[:k] if ranked else movies[:k]
