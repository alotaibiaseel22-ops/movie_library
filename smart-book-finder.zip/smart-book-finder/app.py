from flask import Flask, render_template, request
import csv
import google.generativeai as genai

# Replace with your actual Gemini API key
genai.configure(api_key="PASTE_YOUR_API_KEY")
# Add this to check available models
print(genai.list_models())
model = genai.GenerativeModel("gemini-1.5-pro")

app = Flask(__name__)

def get_books():
    with open("books.csv", newline="") as csvfile:
        return list(csv.DictReader(csvfile))

def recommend_books(user_input):
    prompt = f"Suggest 2 book titles for a student interested in: {user_input}"
    response = model.generate_content(prompt)
    return response.text.strip()

def analyze_summary(summary):
    prompt = f"Give an inspirational insight or key takeaway for this book summary:\n\n{summary}"
    response = model.generate_content(prompt)
    return response.text.strip()


@app.route("/", methods=["GET", "POST"])
def index():
    books = get_books()
    recommendation = ""
    if request.method == "POST":
        user_input = request.form["interest"]
        recommendation = recommend_books(user_input)
    return render_template("index.html", books=books, recommendation=recommendation)

@app.route("/analyze", methods=["POST"])
def analyze_book():
    title = request.form["book"]
    books = get_books()
    selected = next((b for b in books if b["title"] == title), None)
    insight = ""
    if selected:
        insight = analyze_summary(selected["summary"])
    return render_template("analysis.html", title=title, summary=selected["summary"], insight=insight)

if __name__ == "__main__":
    app.run(debug=True)
